class House < ApplicationRecord
end
